/*
 * ============================================================================
 * fourier_mpi.c - Calculo paralelo de la Serie de Fourier con MPI
 * ============================================================================
 *
 * Compilar:  mpicc -Wall -Wextra -O3 -o fourier_mpi fourier_mpi.c -lm
 * Ejecutar:  mpirun --mca btl ^tcp -np 4 ./fourier_mpi
 * ============================================================================
 */

#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* -- Constantes ----------------------------------------------------------- */
#define NUM_PUNTOS    64
#define NUM_TERMINOS  50

#define CSV_HOJA1     "hoja1.csv"
#define CSV_HOJA2     "hoja2.csv"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/* -- Estructura de datos -------------------------------------------------- */
typedef struct {
    double x_vals[NUM_PUNTOS];
    double hoja1_fx[NUM_PUNTOS];
    double hoja2_terminos[NUM_PUNTOS][NUM_TERMINOS];
    double hoja2_a0;
    double hoja2_Fx[NUM_PUNTOS];
    double hoja2_fx[NUM_PUNTOS];
} DatosFourier;

/* -- Funciones matematicas ------------------------------------------------ */
static double f(double x) {
    return pow(x, 4) - 3.0 * x;
}

static double termino_fourier(int n, double x) {
    double n2 = (double)n * (double)n;
    double n4 = n2 * n2;
    double signo = (n % 2 == 0) ? 1.0 : -1.0;
    double pi2 = M_PI * M_PI;

    double an = (8.0 * pi2 * n2 - 48.0) * signo / n4;
    double bn = 6.0 * signo / (double)n;

    return an * cos((double)n * x) + bn * sin((double)n * x);
}

static void generar_puntos_x(double *x_vals) {
    x_vals[0] = -3.1416;
    for (int i = 1; i <= 62; i++) {
        x_vals[i] = -3.1416 + i * 0.1;
    }
    x_vals[63] = 3.1416;
}

/* -- Escritura de CSV ----------------------------------------------------- */
static void escribir_hoja1(DatosFourier *datos) {
    FILE *fp = fopen(CSV_HOJA1, "w");
    if (!fp) {
        perror("Error al crear hoja1.csv");
        return;
    }

    fprintf(fp, "\"f(x) = (x^4) - 3x\"\n\n\nx,f(x)\n");
    for (int i = 0; i < NUM_PUNTOS; i++) {
        fprintf(fp, "%.10g,%.15g\n", datos->x_vals[i], datos->hoja1_fx[i]);
    }
    fclose(fp);
    printf("[Maestro] Archivo %s generado correctamente.\n", CSV_HOJA1);
}

static void escribir_hoja2(DatosFourier *datos) {
    FILE *fp = fopen(CSV_HOJA2, "w");
    if (!fp) {
        perror("Error al crear hoja2.csv");
        return;
    }

    fprintf(fp, "\n\"F(x) = ((2*(PI^4)/5)/2) + suma((((8(PI^2)*(n^2)-48)*((-1)^n)/(n^4))*cos(nx))+(((6*((-1)^n))/n)*sin(nx))) desde n=1 hasta infinito\"\n");

    for (int n = 1; n <= NUM_TERMINOS; n++) {
        fprintf(fp, ",n =");
    }
    fprintf(fp, ",,,,\n");

    fprintf(fp, "x");
    for (int n = 1; n <= NUM_TERMINOS; n++) {
        fprintf(fp, ",%d", n);
    }
    fprintf(fp, ",a0,x,F(X),f(x)\n");

    for (int i = 0; i < NUM_PUNTOS; i++) {
        fprintf(fp, "%.10g", datos->x_vals[i]);
        for (int n = 0; n < NUM_TERMINOS; n++) {
            fprintf(fp, ",%.15g", datos->hoja2_terminos[i][n]);
        }
        fprintf(fp, ",%.15g,%.10g,%.15g,%.15g\n",
                datos->hoja2_a0,
                datos->x_vals[i],
                datos->hoja2_Fx[i],
                datos->hoja2_fx[i]);
    }

    fclose(fp);
    printf("[Maestro] Archivo %s generado correctamente.\n", CSV_HOJA2);
}

/* -- Main ----------------------------------------------------------------- */
int main(int argc, char **argv) {
    int rank = 0;
    int world_size = 0;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    if (world_size != 4) {
        if (rank == 0) {
            printf("Error: se requieren exactamente 4 procesos (1 maestro + 3 trabajadores).\n");
        }
        MPI_Finalize();
        return 0;
    }

    DatosFourier datos;
    memset(&datos, 0, sizeof(DatosFourier));

    if (rank == 0) {
        printf("============================================================\n");
        printf("  Serie de Fourier - Calculo Paralelo con MPI\n");
        printf("  Procesos: %d (1 maestro + %d trabajadores)\n", world_size, world_size - 1);
        printf("============================================================\n\n");

        generar_puntos_x(datos.x_vals);
        datos.hoja2_a0 = (2.0 * pow(M_PI, 4)) / 5.0;
    }

    MPI_Bcast(datos.x_vals, NUM_PUNTOS, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&datos.hoja2_a0, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    int workers = world_size - 1;
    int local_start = 0;
    int local_end = 0;

    if (rank > 0) {
        int worker_index = rank - 1;
        int rows_base = NUM_PUNTOS / workers;
        int rows_rem = NUM_PUNTOS % workers;
        int extra = (worker_index < rows_rem) ? 1 : 0;

        local_start = worker_index * rows_base + (worker_index < rows_rem ? worker_index : rows_rem);
        local_end = local_start + rows_base + extra;
    }

    int local_count = (local_end > local_start) ? (local_end - local_start) : 0;

    double *local_hoja1 = (local_count > 0) ? (double *)calloc((size_t)local_count, sizeof(double)) : NULL;
    double *local_terminos = (local_count > 0)
        ? (double *)calloc((size_t)local_count * (size_t)NUM_TERMINOS, sizeof(double))
        : NULL;
    double *local_Fx = (local_count > 0) ? (double *)calloc((size_t)local_count, sizeof(double)) : NULL;
    double *local_fx = (local_count > 0) ? (double *)calloc((size_t)local_count, sizeof(double)) : NULL;

    if (rank > 0 && local_count == 0) {
        printf("[Trabajador %d] Sin filas asignadas.\n", rank);
    }

    if (rank > 0) {
        printf("[Trabajador %d] Calculando filas [%d, %d)\n", rank, local_start, local_end);
        for (int fila = local_start; fila < local_end; fila++) {
            int local_idx = fila - local_start;
            double x = datos.x_vals[fila];

            local_hoja1[local_idx] = f(x);

            double suma = 0.0;
            for (int n = 1; n <= NUM_TERMINOS; n++) {
                double term = termino_fourier(n, x);
                local_terminos[local_idx * NUM_TERMINOS + (n - 1)] = term;
                suma += term;
            }

            local_Fx[local_idx] = (datos.hoja2_a0 / 2.0) + suma;
            local_fx[local_idx] = f(x);
        }
        printf("[Trabajador %d] Trabajo finalizado.\n", rank);
    }

    int recv_counts[4] = {0, 0, 0, 0};
    int recv_displs[4] = {0, 0, 0, 0};
    int recv_counts_terms[4] = {0, 0, 0, 0};
    int recv_displs_terms[4] = {0, 0, 0, 0};

    if (rank == 0) {
        int offset = 0;
        int offset_terms = 0;
        for (int r = 1; r < world_size; r++) {
            int worker_index = r - 1;
            int rows_base = NUM_PUNTOS / workers;
            int rows_rem = NUM_PUNTOS % workers;
            int extra = (worker_index < rows_rem) ? 1 : 0;
            int start = worker_index * rows_base + (worker_index < rows_rem ? worker_index : rows_rem);
            int end = start + rows_base + extra;
            int count = (end > start) ? (end - start) : 0;

            recv_counts[r] = count;
            recv_displs[r] = offset;
            recv_counts_terms[r] = count * NUM_TERMINOS;
            recv_displs_terms[r] = offset_terms;

            offset += count;
            offset_terms += count * NUM_TERMINOS;
        }
    }

    MPI_Gatherv(local_hoja1, local_count, MPI_DOUBLE,
                datos.hoja1_fx, recv_counts, recv_displs, MPI_DOUBLE,
                0, MPI_COMM_WORLD);

    MPI_Gatherv(local_Fx, local_count, MPI_DOUBLE,
                datos.hoja2_Fx, recv_counts, recv_displs, MPI_DOUBLE,
                0, MPI_COMM_WORLD);

    MPI_Gatherv(local_fx, local_count, MPI_DOUBLE,
                datos.hoja2_fx, recv_counts, recv_displs, MPI_DOUBLE,
                0, MPI_COMM_WORLD);

    MPI_Gatherv(local_terminos, local_count * NUM_TERMINOS, MPI_DOUBLE,
                &(datos.hoja2_terminos[0][0]), recv_counts_terms, recv_displs_terms,
                MPI_DOUBLE, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        printf("\n[Maestro] Todos los trabajadores han terminado. Escribiendo CSV...\n\n");
        escribir_hoja1(&datos);
        escribir_hoja2(&datos);
        printf("\n[Maestro] Programa finalizado con exito.\n");
    }

    free(local_hoja1);
    free(local_terminos);
    free(local_Fx);
    free(local_fx);

    MPI_Finalize();
    return 0;
}
